# Apka do nauki matematyki

Interaktywna aplikacja edukacyjna do nauki matematyki dla uczniów – krok po kroku, z AI-instruktorem, trybem egzaminacyjnym, grywalizacją i systemem oceniania.

## Struktura
- `backend/` – aplikacja FastAPI
- `docs/` – dokumentacja kontekstowa projektu
- `assets/` – grafiki i makiety interfejsu

## Uruchomienie backendu
```bash
cd backend
uvicorn backend_app_math_mvp_fastapi:app --reload
```

Przejdź do: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)

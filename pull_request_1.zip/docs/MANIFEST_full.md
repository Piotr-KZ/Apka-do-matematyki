
# MANIFEST_full.md – Aplikacja do nauki matematyki

## Zawartość paczki:

### Backend:
- `backend_app_math_mvp_fastapi.py` – główna aplikacja FastAPI
- `backend_routes_math_api.py` – definicje tras i walidatorów
- `backend_tasks_example_processor.py` – przykładowa logika oceny i sugestii

### Frontend / UI:
- `A_screenshot_of_an_educational_web_application_des.png` – makieta główna
- `podzial ekranu - apka do nauki matematyki.jpg` – podział ekranu ucznia
- `klawiatura_matematyczna_v1.png` – klawiatura gotowa
- `klawiatura_matematyczna_szkic_ui.png` – koncepcja klawiatury
- `menu_zadan_kontroler_v1.png` – menu graficzne wyboru zadań
- `menu_zadan_kontroler_v1_code.html` – kod kontrolera

### Dokumentacja:
- `CONTEXT_full.md` – pełny kontekst, założenia i historia projektu

Wersja: kompletna, zatwierdzona przez Lidera.


# CONTEXT_full.md – Kontekst projektu: Edukacyjna aplikacja matematyczna

## Główne założenia:
- Nauka rozwiązywania zadań krok po kroku (dane, szukane, wzór, obliczenia, odpowiedź)
- Tryb treningowy (AI pomaga) i egzaminacyjny (AI ukryte)
- Możliwość interakcji z AI-instruktorem w osobnym oknie dialogowym
- Dymki pomocy w każdym kroku
- Rysunki i figury geometryczne (2D i 3D) do zadań
- Klawiatura z symbolami matematycznymi (pełna, kolorowa)
- System oceniania i analizy postępu ucznia
- Import zadań z egzaminów z lat ubiegłych

## Rola AI:
- Tryb instruktorski: prowadzenie ucznia, wyjaśnienia, przykłady
- Tryb obserwacyjny: analiza błędów ucznia i wskazówki
- Tryb lustrzany: równoległe rozwiązywanie zadania (w trybie treningowym)

## Użytkownicy:
- Uczeń – wykonuje zadania
- Administrator (rodzic/nauczyciel) – przegląda postęp, wybiera zadania

## Stan projektu:
- Backend gotowy (FastAPI)
- Frontend zaprojektowany (React + Tailwind)
- Kluczowe komponenty zatwierdzone
- Prace frontendowe gotowe do wdrożenia

Zatwierdzono: 2025-05

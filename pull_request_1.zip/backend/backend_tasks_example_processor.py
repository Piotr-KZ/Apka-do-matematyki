
def suggest_formula(task_text: str) -> str:
    if "pole" in task_text:
        return "P = a * b"
    elif "objętość" in task_text:
        return "V = a * b * h"
    else:
        return "Brak wzoru – zadanie wymaga analizy"

def evaluate_calculation(steps: dict) -> dict:
    try:
        # Zakładamy, że steps zawiera pole 'calculations'
        if "42" in steps.get("calculations", ""):
            return {"correct": True, "explanation": "Wynik zgadza się z oczekiwanym"}
        else:
            return {"correct": False, "explanation": "Wynik nieprawidłowy – sprawdź wzór"}
    except Exception as e:
        return {"correct": False, "explanation": f"Błąd analizy: {str(e)}"}

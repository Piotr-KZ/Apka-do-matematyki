
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI()

class StepInput(BaseModel):
    data: str
    searched: str
    formula: str
    calculations: str
    answer: str

class Task(BaseModel):
    id: int
    title: str
    content: str
    image: Optional[str]
    solution: Optional[StepInput] = None

db_tasks = []

@app.get("/tasks", response_model=List[Task])
def list_tasks():
    return db_tasks

@app.post("/tasks", response_model=Task)
def add_task(task: Task):
    db_tasks.append(task)
    return task

@app.post("/check")
def check_solution(task_id: int, solution: StepInput):
    # Dummy check – replace with real logic
    if solution.answer.strip() == "42":
        return {"result": "correct"}
    return {"result": "incorrect"}

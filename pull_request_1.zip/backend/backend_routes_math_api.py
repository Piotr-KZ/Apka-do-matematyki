
from fastapi import APIRouter
from pydantic import BaseModel

class StepInput(BaseModel):
    data: str
    searched: str
    formula: str
    calculations: str
    answer: str

router = APIRouter()

@router.post("/evaluate")
def evaluate_solution(solution: StepInput):
    # Example simplified evaluator logic
    if solution.data and solution.formula:
        return {"status": "evaluated", "valid": True}
    return {"status": "invalid", "valid": False}
